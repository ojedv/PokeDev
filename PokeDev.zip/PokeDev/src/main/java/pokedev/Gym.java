package main.java.pokedev;

public class Gym {
    private String nombreGym;
    private Medal medalla;
    private Region region;
    private Trainer lider; // Líder del gimnasio, un entrenador con sus Pokémon

    public Gym(String nombreGym, Medal medalla, Region region, Trainer lider) {
        this.nombreGym = nombreGym;
        this.medalla = medalla;
        this.region = region;
        this.lider = lider;
    }

    public String getNombreGym() {
        return nombreGym;
    }

    public Medal getMedalla() {
        return medalla;
    }

    public Region getRegion() {
        return region;
    }

    public Trainer getLider() {
        return lider;
    }

    public boolean desafiarGimnasio(Trainer jugador) {
        System.out.println("¡Te enfrentas al líder del gimnasio " + nombreGym + "!");

        Battle batalla = new Battle(jugador, lider);
        boolean gano = batalla.iniciarCombate();

        if (gano) {
            System.out.println("¡Has ganado la medalla " + medalla.getNombre() + "!");
            jugador.recibirMedalla(medalla);
        } else {
            System.out.println("¡Perdiste el combate! Intenta de nuevo.");
        }

        return gano;
    }

    public Medal getMedal() {
        return medalla;
    }
}
