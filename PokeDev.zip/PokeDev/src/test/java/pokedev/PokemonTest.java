package main.java.pokedev;

import main.java.pokedev.Pokemon;
import main.java.pokedev.Type;

public class PokemonTest {
    public static void main(String[] args) {
        // Prueba 1: Verificar si el nivel de un Pokémon sube correctamente
        Pokemon pikachu = new Pokemon(25, "Pikachu");
        pikachu.subirDeNivel(); // Método que sube el nivel del Pokémon
        assert pikachu.getNivel() == 2 : "Error: El nivel debería ser 2 después de subirlo.";

        // Prueba 2: Verificar la efectividad de un ataque
        Type tipoAtaque = Type.ELECTRICO;
        Type tipoPokemon = Type.AGUA;
        assert pikachu.esEfectivo(tipoAtaque, tipoPokemon) : "Error: El ataque debería ser efectivo contra agua.";

        System.out.println("Todas las pruebas de Pokémon pasaron correctamente.");
    }
}
