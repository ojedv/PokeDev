package main.java.pokedev.interfaces;

public interface TFuego {
    public void atacarPunioFuego();
    public void atacarLanzallamas();
    public void atacarAscuas();
}
