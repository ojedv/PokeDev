package main.java.pokedev;

public class Professor extends Person {
    private String region;

    public Professor(String nombre, int edad, String region) {
        super(nombre, edad);
        this.region = region;
    }

    public String getRegion() {
        return region;
    }

    public void darPokemonInicial(Trainer entrenador, Pokemon pokemon) {
        System.out.println("El Profesor " + getNombre() + " te ha dado a " + pokemon.getNombre() + " como tu Pokémon inicial.");
        entrenador.recibirPokemon(pokemon);
    }
}
