package main.java.pokedev;

public class Medal {
    public String nombreMedal;

    public Medal(String medal){
        this.nombreMedal = medal;
    }

    public String getNombreMedal() { // <-- Agregado
        return nombreMedal;
    }

    public String getNombre() {
        return nombreMedal;
    }
}
