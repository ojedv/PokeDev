package main.java.pokedev;

import java.util.ArrayList;
import java.util.List;

public class Trainer extends Person {
    private List<Pokemon> equipo;
    private List<Medal> medallas;

    public Trainer(String nombre, int edad) {
        super(nombre, edad);
        this.equipo = new ArrayList<>();
        this.medallas = new ArrayList<>();
    }

    public void recibirPokemon(Pokemon pokemon) {
        if (equipo.size() < 6) {
            equipo.add(pokemon);
            System.out.println(getNombre() + " ha recibido a " + pokemon.getNombre() + "!");
        } else {
            System.out.println("¡No puedes llevar más de 6 Pokémon en tu equipo!");
        }
    }

    public void mostrarEquipo() {
        System.out.println("Equipo de " + getNombre() + ":");
        for (Pokemon p : equipo) {
            System.out.println("- " + p.getNombre() + " (Nivel " + p.getNivel() + ")");
        }
    }

    public void recibirMedalla(Medal medal) {
        medallas.add(medal);
        System.out.println(getNombre() + " ha ganado la medalla " + medal.getNombre() + "!");
    }

    public List<Pokemon> getEquipo() {
        return equipo;
    }

    public List<Medal> getMedallas() {
        return medallas;
    }
}
