package main.java.pokedev;

import main.java.pokedev.Trainer;

public class TrainerTest {
    public static void main(String[] args) {
        Trainer entrenador = new Trainer("Ash", 10);

        assert entrenador.getNombre().equals("Ash") : "Error: El nombre del entrenador no es correcto.";
        assert entrenador.getEdad() == 10 : "Error: La edad del entrenador no es correcta.";

        System.out.println("✅ TrainerTest pasó correctamente.");
    }
}
