package main.java.pokedev;

import main.java.pokedev.Gym;
import main.java.pokedev.Medal;
import main.java.pokedev.Region;
import main.java.pokedev.Trainer;

public class GymTest {
    public static void main(String[] args) {
        Region region = new Region("Kanto");
        Medal medalla = new Medal("Medalla Roca");
        Trainer lider = new Trainer("Brock", 25);
        Gym gimnasio = new Gym("Gimnasio Pewter", medalla, region, lider);

        assert gimnasio.getNombreGym().equals("Gimnasio Pewter") : "Error: Nombre del gimnasio incorrecto.";
        assert gimnasio.getMedal().getNombreMedal().equals("Medalla Roca") : "Error: Medalla incorrecta.";
        assert gimnasio.getRegion().getNombreRegion().equals("Kanto") : "Error: Región incorrecta.";
        assert gimnasio.getLider().getNombre().equals("Brock") : "Error: Líder incorrecto.";

        System.out.println("✅ GymTest pasó correctamente.");
    }
}
