package main.java.pokedev.interfaces;

public interface TElectrico {
    public void atacarInpactrueno();
    public void atacarPuniotrueno();
}
