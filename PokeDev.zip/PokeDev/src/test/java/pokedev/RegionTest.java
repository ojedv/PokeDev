package main.java.pokedev;

public class RegionTest {
    public static void main(String[] args) {
        Region region = new Region("Kanto");

        assert region.getNombreRegion().equals("Kanto") : "Error: El nombre de la región no es correcto.";

        System.out.println("✅ RegionTest pasó correctamente.");
    }
}
