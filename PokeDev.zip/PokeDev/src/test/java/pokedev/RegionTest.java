package main.java.pokedev;

import org.junit.Test;

public class RegionTest {
        @Test
        public void getRegion(){
            Region region = new Region("Kanto");

        }
}
