package main.java.pokedev.interfaces;

public interface TAgua {
        public void atacarHidrobomba();
        public void atacarBurbuja();
        public void atacarPistolaAgua();
}
