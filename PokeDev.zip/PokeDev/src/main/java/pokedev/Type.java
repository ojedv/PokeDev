package main.java.pokedev;

public enum Type {
    FUEGO("Fuego", "Fuerte contra Planta, Débil contra Agua"),
    AGUA("Agua", "Fuerte contra Fuego, Débil contra Eléctrico"),
    PLANTA("Planta", "Fuerte contra Agua, Débil contra Fuego"),
    ELECTRICO("Eléctrico", "Fuerte contra Agua, Débil contra Tierra"),
    PSIQUICO("Psíquico", "Fuerte contra Veneno, Débil contra Siniestro"),
    VENENO("Veneno", "Fuerte contra Hada, Débil contra Psíquico"),
    LUCHADOR("Luchador", "Fuerte contra Normal, Débil contra Psíquico"),
    VOLADOR("Volador", "Fuerte contra Planta, Débil contra Eléctrico"),
    SINIETRO("Siniestro", "Fuerte contra Psíquico, Débil contra Hada"),
    HADA("Hada", "Fuerte contra Lucha, Débil contra Veneno");

    private final String nombre;
    private final String descripcion;

    Type(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }
}
