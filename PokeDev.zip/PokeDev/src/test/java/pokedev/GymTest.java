package main.java.pokedev;

import main.java.pokedev.Gym;
import main.java.pokedev.Medal;
import main.java.pokedev.Region;
import main.java.pokedev.Trainer;
import org.junit.Test;

public class GymTest {
   @Test
    public void getMedal(){
       String medalname = "plata";
       Medal medal = new Medal(medalname);
   }
}
