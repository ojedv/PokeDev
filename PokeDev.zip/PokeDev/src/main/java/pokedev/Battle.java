package main.java.pokedev;

public class Battle {
    private Trainer jugador;
    private Trainer lider;

    // Constructor para la batalla
    public Battle(Trainer jugador, Trainer lider) {
        this.jugador = jugador;
        this.lider = lider;
    }

    // Método que simula el combate
    public boolean iniciarCombate() {
        System.out.println("¡La batalla comienza entre " + jugador.getNombre() + " y " + lider.getNombre() + "!");
        double probabilidadGanadora = Math.random();
        return probabilidadGanadora > 0.5;
    }
}
