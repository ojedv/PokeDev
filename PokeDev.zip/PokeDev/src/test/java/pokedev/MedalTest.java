package main.java.pokedev;

import main.java.pokedev.Medal;

public class MedalTest {
    public static void main(String[] args) {
        Medal medalla = new Medal("Medalla Fuego");

        assert medalla.getNombreMedal().equals("Medalla Fuego") : "Error: El nombre de la medalla no es correcto.";

        System.out.println("✅ MedalTest pasó correctamente.");
    }
}
