package main.java.pokedev;

public class Region {
    private String nombreRegion; // <-- Debe ser privado para encapsulación

    public Region(String nombre){
        this.nombreRegion = nombre;
    }

    public String getNombreRegion() { // <-- Agregado
        return nombreRegion;
    }
}
