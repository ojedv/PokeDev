package main.java.pokedev;

public class Pokemon {
    private int numPokedex;
    private String nombre;
    private String tipo;
    private int nivel;
    private int ps; // Vida

    public Pokemon(int numPokedex, String nombre, String tipo, int nivel, int ps) {
        this.numPokedex = numPokedex;
        this.nombre = nombre;
        this.tipo = tipo;
        this.nivel = nivel;
        this.ps = ps;
    }

    public Pokemon(int numPokedex) {
    }

    public Pokemon(int i, String nombre) {
    }

    public int getNumPokedex() {
        return numPokedex;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public int getNivel() {
        return nivel;
    }

    public int getPs() {
        return ps;
    }

    public void setPs(int ps) {
        this.ps = Math.max(ps, 0); // Evita que los PS sean negativos
    }

    public void subirNivel() {
        nivel++;
        System.out.println(nombre + " ha subido al nivel " + nivel + "!");
    }

    public void recibirDanio(int danio) {
        setPs(ps - danio);
        System.out.println(nombre + " ha recibido " + danio + " de daño. PS restantes: " + ps);
    }

    public void subirDeNivel() {
    }

    public boolean esEfectivo(Type tipoAtaque, Type tipoPokemon) {
        // Las relaciones de efectividad pueden variar. Por ejemplo:
        if (tipoAtaque == Type.FUEGO && tipoPokemon == Type.PLANTA) {
            return true; // Fuego es efectivo contra Planta
        }
        if (tipoAtaque == Type.AGUA && tipoPokemon == Type.FUEGO) {
            return true; // Agua es efectivo contra Fuego
        }
        if (tipoAtaque == Type.PLANTA && tipoPokemon == Type.AGUA) {
            return true; // Planta es efectivo contra Agua
        }
        if (tipoAtaque == Type.ELECTRICO && tipoPokemon == Type.AGUA) {
            return true; // Eléctrico es efectivo contra Agua
        }

        // Para otros tipos, puedes añadir más reglas según las relaciones de efectividad
        // Si el tipo de ataque y el tipo del Pokémon son el mismo, se considera "no efectivo"
        if (tipoAtaque == tipoPokemon) {
            return false;
        }

        // Para el resto de casos, se puede considerar que no es efectivo
        return false;
    }

}
