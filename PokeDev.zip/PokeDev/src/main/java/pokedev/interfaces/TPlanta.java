package main.java.pokedev.interfaces;

public interface TPlanta {
    public void atacarDrenaje();
    public void atacarParalizar();
}
