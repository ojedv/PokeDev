package main.java.pokedev;

public enum Item {
    POCION("Poción", "Recupera 20 PS."),
    SUPERPOCION("Superpoción", "Recupera 50 PS."),
    HIPERPOCION("Hiperpoción", "Recupera 200 PS."),
    REVIVIR("Revivir", "Revive a un Pokémon con la mitad de su PS."),
    MAX_REVIDIR("Máx. Revivir", "Revive a un Pokémon con todos sus PS."),
    ANTIDOTO("Antídoto", "Cura envenenamiento."),
    BAYA_ZAFIRO("Baya Zafiro", "Recupera 10 PS."),
    POKE_BALL("Poké Ball", "Permite capturar Pokémon salvajes."),
    SUPER_BALL("Super Ball", "Tiene más efectividad que una Poké Ball."),
    ULTRA_BALL("Ultra Ball", "Tiene más efectividad que una Super Ball.");

    private final String nombre;
    private final String descripcion;

    Item(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }
}
